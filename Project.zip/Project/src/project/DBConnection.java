/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project;

/**
 *
 * @author Cliff
 */
import java.sql.*;
import com.mysql.jdbc.Connection;

public class DBConnection {
    
    private Connection DBConnection;
    public Connection connect(){
        
        try{
            Class.forName("com.mysql.jdbc.Driver");
            System.out.println("It's OK..........");
        }
        
        catch(ClassNotFoundException cnfe){
            System.out.println("Not OK "+cnfe);
        }
        
        String url="jdbc:mysql://localhost:3306/project";
        
        try{
            DBConnection=(Connection)DriverManager.getConnection(url,"root","root");
             System.out.println("DB OK...........");
        }
        
       catch(SQLException se){
           System.out.println("DB NOT OK....."+se);
           
       }
        
        return DBConnection;
        
    }
    
    
    
}
